//
//  roster.hpp
//  StudentDataTable
//
//  Created by Isabelle on 5/10/20.
//  Copyright © 2020 Isabelle Matthews. All rights reserved.
//

#ifndef roster_h
#define roster_h

#include <stdio.h>
#include "student.h"

using std::string;

class Roster{
    
public:
    
    Student* classRosterArray[5] = { nullptr, nullptr, nullptr, nullptr, nullptr};
    int index = 0;
    
void add(string Id, string fName, string lName, string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram deg);
void remove(string Id);
    void printAll();
    void printAverageDaysInCourse(string Id);
    void printInvalidEmails();
    void printbyDegreeProgram(DegreeProgram deg);
    
    Roster();
    ~Roster();
};

#endif /* roster_h */
