//
//  roster.cpp
//  StudentDataTable
//
//  Created by Isabelle on 5/10/20.
//  Copyright © 2020 Isabelle Matthews. All rights reserved.
//

#include <iostream>
#include <string>
#include "roster.h"
using namespace std;

void Roster::add (string Id, string fName, string lName, string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram deg)
{
    int dic[3];
    dic[0] = daysInCourse1;
    dic[1] = daysInCourse2;
    dic[2] = daysInCourse3;
    
    classRosterArray[index++] = new Student (Id, fName, lName, email, age, dic, deg);
    
}

void Roster::remove(string Id) {
    bool studentFound = false;
    for(int i=0;i<5;i++) {
        string currentId = classRosterArray[i]->getStudentId();
        if (currentId == Id) {
        }
    }

    if (studentFound == false) {
        cout << "\nStudent ID cannot be found";
}
}

void Roster::printAll() {
    for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
        classRosterArray[i]->print();
    }
    return;
}


void Roster::printAverageDaysInCourse(string Id)
{
    for(int i = 0; i < 5; i++) {
        string currentId = classRosterArray[i]->getStudentId();
        if (currentId == Id) {

int daysInCourse1 = classRosterArray[i]->getDaysInCourse()[0];
int daysInCourse2 = classRosterArray[i]->getDaysInCourse()[1];
int daysInCourse3 = classRosterArray[i]->getDaysInCourse()[2];
            
cout << "\naverage days in course for student " << Id << " " << (daysInCourse1 + daysInCourse2 + daysInCourse3) / 3;
}
}
}

void Roster::printInvalidEmails() {
    for (int i = 0; i < 5; i++ ) {

string currentEmail = classRosterArray[i]->getEmailAddress();
string space = " ";
string emailSymbol = "@";
string period = ".";
        
bool isEmailInvalid = false;
        
if(isEmailInvalid) {
            
cout << "Email Address Invalid " << currentEmail << endl;
}
}
}

void Roster::printbyDegreeProgram(DegreeProgram deg) {
    cout << "\nPrinting students in degree program" << " " << DegreeProgramStrings[deg];
    
    for (int i=0;i<5;i++) {
      //  DegreeProgram currentDegreeProgram = classRosterArray[i]->getDegree();
        
    if(this->classRosterArray[i]->getDegree() == deg) {
           classRosterArray[i]->print();
}
}
}

    Roster::~Roster() {
        for (int i = 0;i<5;i++) {
        
classRosterArray[i] = nullptr;
}
    return;
}

    Roster::Roster()
{
        return;
    }
