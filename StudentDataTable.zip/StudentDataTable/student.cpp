//
//  student.cpp
//  StudentDataTable
//
//  Created by Isabelle on 5/10/20.
//  Copyright © 2020 Isabelle Matthews. All rights reserved.
//

#include <iostream>
#include <string>
#include "student.h"
using namespace std;

// constructor

Student::Student (string Id, string fName, string lName, string email, int age, int dic[], DegreeProgram deg){
    this->StudentId = Id;
    this->FirstName = fName;
    this->LastName = lName;
    this->EmailAddress = email;
    this->Age = age;
    for (int i = 0; i < daysInCourseArraySize; i++)
    {
        this->DaysInCourse[i] = dic[i];
    }
    this->degree = deg;
}

// setters

void Student::setStudentId (string Id)
{
    this->StudentId = Id;
}

void Student:: setFirstName (string fName)
{
    this->FirstName = fName;
}

void Student:: setLastName(string lName)
{
    this->LastName = lName;
}
    
void Student:: setEmailAddress(string email)
{
    this->EmailAddress = email;
}
void Student:: setAge(int age)
{
    this->Age=age;
}
void Student::setDaysInCourse(int dic[])
{
    this->DaysInCourse[0] = dic[0];
    this->DaysInCourse[1] = dic[1];
    this->DaysInCourse[2] = dic[2];
}
void Student::setDegreeProgram(DegreeProgram deg)
{
    this->degree = deg;
}


/* getter */

string Student::getStudentId()
{
    return StudentId;
}

string Student::getFirstName()
{
    return FirstName;
}
string Student::getLastName()
{
    return LastName;
}
string Student::getEmailAddress()
{
    return EmailAddress;
}
int Student:: getAge()
{
    return Age;
}
    
int* Student::getDaysInCourse()
{
    return DaysInCourse;
}
    
DegreeProgram Student::getDegree()
{
    return degree;
}

void Student::print()
{
    cout << "\nStudent ID: " + getStudentId();
    cout << "\nFirst Name: " + getFirstName();
    cout << "\nLast Name: " + getLastName();
    cout << "\nEmail Address: " + getEmailAddress();
    cout << "\nAge: " << getAge();

    const int* days = getDaysInCourse();
    std::cout << "\nDays In Course: " << days[0] << ", " << days[1] << ", " << days[2];
    switch (getDegree())
    {
    case DegreeProgram::NETWORK:
        std::cout << "\nDegree Program: NETWORK";
        break;
    case DegreeProgram::SECURITY:
        std::cout << "\nDegree Program: SECURITY";
        break;
    case DegreeProgram::SOFTWARE:
        std::cout << "\nDegree Program: SOFTWARE";
        break;
    default:
        std::cout << "\nDegree Program: DEFAULT";
}
}
