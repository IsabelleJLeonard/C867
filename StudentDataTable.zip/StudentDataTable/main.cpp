//
//  main.cpp
//  StudentDataTable
//
//  Created by Isabelle on 5/10/20.
//  Copyright © 2020 Isabelle Matthews. All rights reserved.
//

#include <iostream>
#include <string>
#include "roster.h"
using namespace std;

int main() {
    
  const string studentData[] = {
"A1,John,Smith,John1989@gmail.com,20,30,35,40,SECURITY",
"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
"A5,Isabelle,Matthews,imatt12@wgu.edu,25,50,40,30,SOFTWARE"
};
    
    const int numStudents = 5;
    
    Roster classRoster;
    
    for (int i = 0; i < numStudents; i++) {
        string s = studentData[i];
       
        size_t rhs = studentData[i].find(",");
        string currentId = studentData[i].substr(0, rhs);
        
        size_t lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        string currentFName = studentData[i].substr(lhs, rhs - lhs);
                    
        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        string currentLName = studentData[i].substr(lhs, rhs - lhs);
        
        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        string currentEmail = studentData[i].substr(lhs, rhs - lhs);
        
        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        string currentAgeString = studentData[i].substr(lhs, rhs - lhs);
        int currentAge = stoi(currentAgeString);

        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        int daysInCourse1 = stod(studentData[i].substr(lhs, rhs - lhs));
        

        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        int daysInCourse2 = stod(studentData[i].substr(lhs, rhs - lhs));

        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        int daysInCourse3 = stod(studentData[i].substr(lhs, rhs - lhs));
                
        lhs = rhs + 1;
        rhs = studentData[i].find(",", lhs);
        string degreeTypeString = studentData[i].substr(lhs, rhs - lhs);
        
        DegreeProgram deg;
        if (degreeTypeString == "SECURITY") deg =  SECURITY;
        if (degreeTypeString == "NETWORK") deg = NETWORK;
        if (degreeTypeString == "SOFTWARE") deg = SOFTWARE;

    
        classRoster.add(currentId, currentFName, currentLName, currentEmail, currentAge, daysInCourse1, daysInCourse2, daysInCourse3, deg);
   }
        
    //student info
    cout << "Student Data Table" << endl;
    cout << "Course title: Scritping and Programming Applications C867" << endl;
    cout << "Programming language: C++" << endl;
    cout << "WGU Student ID: 001115568" << endl;
    cout << "Name: Isabelle Matthews" << endl;

    
    classRoster.printAll();
    cout << endl;
    
    classRoster.printInvalidEmails();
    cout << endl;
    
    //loop through classRosterArray and for every element

    for (int i=0; i < 5; i++){
        classRoster.printAverageDaysInCourse(classRoster.classRosterArray[i]->getStudentId());
    
    }
    
    classRoster.printbyDegreeProgram(DegreeProgram::SOFTWARE);
    cout << endl;
    
    classRoster.remove("A3");
    classRoster.printAll();
    cout << endl;
    
    classRoster.remove("A3");
    
    //expected: the above line should print a message saying such a student with this ID was not found.
    
}

