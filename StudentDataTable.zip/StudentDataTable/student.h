//
//  student.h
//  StudentDataTable
//
//  Created by Isabelle on 5/10/20.
//  Copyright © 2020 Isabelle Matthews. All rights reserved.
//

#ifndef student_h
#define student_h

#include <iostream>
#include <string>
#include "degree.h"

class Student {
    
private:
    
    string StudentId, FirstName, LastName, EmailAddress;
    int Age;
    int DaysInCourse[3];
    DegreeProgram degree;
    
public:
    
    Student(string Id, string fName, string lName, string email, int age, int dic[], DegreeProgram deg);
    
    const static int daysInCourseArraySize = 3;
    
    //Setters
    void setStudentId(string Id);
    void setFirstName(string fName);
    void setLastName(string lName);
    void setEmailAddress(string email);
    void setAge(int age);
    void setDaysInCourse(int dic[]);
    void setDegreeProgram(DegreeProgram deg);
    
    //Getters
    
    string getStudentId();
    string getFirstName();
    string getLastName();
    string getEmailAddress();
    int getAge();
    int* getDaysInCourse();
    DegreeProgram getDegree();

    
    void print();

};

#endif /* student_h */
