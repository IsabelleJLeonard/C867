//
//  degree.h
//  StudentDataTable
//
//  Created by Isabelle on 5/10/20.
//  Copyright © 2020 Isabelle Matthews. All rights reserved.
//

#ifndef degree_h
#define degree_h

using namespace std;

enum DegreeProgram

{
    SECURITY, NETWORK, SOFTWARE
};

static const std::string DegreeProgramStrings[] = {"SECURITY","NETWORK","SOFTWARE"};

#endif
